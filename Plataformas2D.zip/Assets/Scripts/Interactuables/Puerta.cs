using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Puerta : MonoBehaviour, IInteractuable
{
    // Start is called before the first frame update

    public void Interactuar(GameObject interactuador){

        Debug.Log("Puerta Abierta");
        Destroy(this.gameObject);

        }

    }

