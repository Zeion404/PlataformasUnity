using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PowerUpSalto : MonoBehaviour, IInteractuable
{
    // Start is called before the first frame update
    public void Interactuar(GameObject interactuador){

        Player jugador = interactuador.GetComponent<Player>();
        if (jugador != null)
        {
            jugador.SetDobleSalto();
        }
        Destroy(this.gameObject);

    }
    
}
