using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RespawnVoid : MonoBehaviour
{
    [SerializeField] private Transform spawnPoint;
    [SerializeField] private float danhoCaida;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void OnTriggerEnter2D (Collider2D elOtro){
        if (elOtro.gameObject.CompareTag("PlayerHitbox")){
            elOtro.transform.position = spawnPoint.position;
            SistemaVidas sistemaVidas = elOtro.gameObject.GetComponent<SistemaVidas>();
            sistemaVidas.RecibirDanho(danhoCaida); //Cuando el jugador se caiga del mapa recibe daño
        }

    }
}
