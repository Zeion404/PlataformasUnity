using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering;

public class SistemaVidas : MonoBehaviour
{

    [SerializeField] protected float vidas;
    public void RecibirDanho(float dano){
        vidas -= dano;
        if(vidas <= 0){
            Morir();
        }
    }

    protected virtual void Morir(){
        Destroy(this.gameObject);

    }
}
