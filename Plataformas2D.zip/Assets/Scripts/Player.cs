using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.Rendering;

public class Player : MonoBehaviour
{
    private Rigidbody2D rb;
    private float inputH;
    [Header("Sistema de movimiento")]
    [SerializeField] private float velocidadMovimiento;
    [SerializeField] private float fuerzaSalto;
    [SerializeField] private float fuerzaDash;
    [SerializeField] private float tiempoDash;
    [SerializeField] private float cooldownDash;
    [SerializeField] private Transform pies;
    [SerializeField] private float distanciaSuelo;
    [SerializeField] private LayerMask queEsSaltable;

    //Variables de los poderes que se adquieren
    private bool dobleSalto = false;
    private bool haSaltado2 = false;
   
    
    [Header("Sistema de combate")]
    [SerializeField] private Transform puntoAtaque;
    [SerializeField] private float radioAtaque;
    [SerializeField] private LayerMask queEsDanhable;
    [SerializeField] private float dano;
    private Animator anim;

    [Header("Sistema de interacciones")]
    [SerializeField] private Transform puntoInteraccion;
    [SerializeField] private float radioInteraccion;
    
    [SerializeField] private LayerMask queEsInteractuable;

    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        Movimiento();
        Saltar();
        LanzarAtaque();
        Interactuar();
    }

    private void Movimiento(){

        inputH = Input.GetAxisRaw("Horizontal");
        //No hace falta usar el delta time con velocity, es como un translate pero usando fisicas
        rb.velocity = new Vector2(inputH * velocidadMovimiento, rb.velocity.y);
        if(inputH != 0){
            anim.SetBool("Running", true); 
            if(inputH > 0){
                transform.eulerAngles = Vector3.zero;
            } else{
                transform.eulerAngles = new Vector3(0, 180, 0);
            }
            
        } else{
            anim.SetBool("Running", false); 

        }

    }

    //Implementacion de Interactuar vista en clase para los power Ups y las puertas
    private void Interactuar(){
        if(Input.GetKeyDown(KeyCode.E)){
            Collider2D collDetectado = Physics2D.OverlapCircle(puntoInteraccion.position, radioInteraccion, queEsInteractuable);
            if (collDetectado != null){
                Debug.Log("Interactuando!!!!");

                if(collDetectado.TryGetComponent(out IInteractuable interactuable)){
                    //Para no implementar la clase player como un singleton y tener un static instance del player para poder arrojar
                    //métodos he preferido pasar como parametro al player para poder acceder al metodo publico de activar el doble salto
                    Debug.Log("Interactuando 2222 !!!!");
                    interactuable.Interactuar(this.gameObject);
                    
                }
                
            }
            
        }
    }

    private void Saltar(){

        if(Input.GetKeyDown(KeyCode.Space) && EstoyEnSuelo()){
            
            rb.AddForce(Vector2.up * fuerzaSalto, ForceMode2D.Impulse);
            anim.SetTrigger("Jump");
            haSaltado2 = false;
            //Lógica del salto doble
        }
            else if(Input.GetKeyDown(KeyCode.Space) && dobleSalto && !haSaltado2){
                //Se reinicia la inercia del salto
                rb.velocity = new Vector2(rb.velocity.x, 0);
                rb.AddForce(Vector2.up * fuerzaSalto, ForceMode2D.Impulse);
                haSaltado2 = true;
            }
        
    }



    private bool EstoyEnSuelo(){
       //bool tocado = 
       return Physics2D.Raycast(pies.position, Vector3.down, distanciaSuelo, queEsSaltable);
    }

    private void LanzarAtaque(){

        if(Input.GetMouseButtonDown(0)){
            anim.SetTrigger("Attack");
        }

    }
    //Se ejecuta desde evento de animación
    private void Ataque(){
        Collider2D[] collidersTocados = Physics2D.OverlapCircleAll(puntoAtaque.position, radioAtaque, queEsDanhable);
        foreach (Collider2D item in collidersTocados) {
            SistemaVidas objetivo = item.gameObject.GetComponent<SistemaVidas>();
            objetivo.RecibirDanho(dano);
        }


    }

    private void OnDrawGizmos(){

        Gizmos.DrawSphere(puntoAtaque.position, radioAtaque);
    }


        public void SetDobleSalto(){

        dobleSalto = true;
    }


}  