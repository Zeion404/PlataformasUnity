using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class BolaFuego : MonoBehaviour
{
    Rigidbody2D rb;
    [SerializeField] private float impulsoDisparo;
    [SerializeField] private float duracion;
    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        rb.AddForce(transform.right * impulsoDisparo, ForceMode2D.Impulse);
        StartCoroutine(Despawnear(duracion));
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnTriggerEnter2D(Collider2D elOtro){

        if (elOtro.gameObject.CompareTag("PlayerHitbox")){
            SistemaVidas sistemaVidas = elOtro.gameObject.GetComponent<SistemaVidas>();
            sistemaVidas.RecibirDanho(20);
            Destroy(this.gameObject);
        }
    }
    private void OnCollisionEnter2D(Collision2D elOtro){
        if (elOtro.gameObject.CompareTag("PlayerHitbox")){
            SistemaVidas sistemaVidas = elOtro.gameObject.GetComponent<SistemaVidas>();
            sistemaVidas.RecibirDanho(20);
            Destroy(this.gameObject);
        }
    }

       IEnumerator Despawnear(float time) { //Función de despawneo para que la bola de fuego no dure eternamente
        yield return new WaitForSeconds(time);
        Destroy(this.gameObject);
    }
}
