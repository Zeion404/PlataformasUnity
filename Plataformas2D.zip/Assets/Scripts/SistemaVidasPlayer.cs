using System.Collections;
using System.Collections.Generic;
using System.Net.Sockets;
using UnityEngine;
using UnityEngine.UI;
public class SistemaVidasPlayer : SistemaVidas
{

    [SerializeField] private Image barraDeSalud;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        barraDeSalud.fillAmount = vidas / 100f;
    }

    protected override void Morir(){
        barraDeSalud.fillAmount = 0;
        base.Morir();
    }
}   

